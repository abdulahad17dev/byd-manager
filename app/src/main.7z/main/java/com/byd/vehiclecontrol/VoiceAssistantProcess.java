package com.byd.vehiclecontrol;

import android.util.Log;

/**
 * Главный класс процесса, который запускается через app_process
 * с системными привилегиями
 */
public class VoiceAssistantProcess {
    private static final String TAG = "VoiceAssistantProcess";

    /**
     * Точка входа для app_process
     */
    public static void main(String[] args) {
        Log.d(TAG, "=== VoiceAssistantProcess started ===");
        Log.d(TAG, "Process ID: " + android.os.Process.myPid());
        Log.d(TAG, "User ID: " + android.os.Process.myUid());
        Log.d(TAG, "Arguments: " + java.util.Arrays.toString(args));

        try {
            // Инициализируем Android Looper для работы с системными сервисами
            if (android.os.Looper.getMainLooper() == null) {
                android.os.Looper.prepareMainLooper();
                Log.d(TAG, "Main Looper подготовлен");
            }

            // Инициализируем ActivityThread для получения системного контекста
            initSystemContext();

            // Держим процесс живым для демонстрации
            Log.d(TAG, "Процесс готов к работе, ожидание команд...");

            // Создаем простой loop для демонстрации (в реальности здесь будет IPC сервер)
            int counter = 0;
            while (counter < 10) {
                Thread.sleep(5000);
                counter++;
                Log.d(TAG, "Process alive, counter: " + counter);

                // Периодически тестируем доступ к автомобильному сервису
                if (counter % 3 == 0) {
                    testAutoService();
                }
            }

            Log.d(TAG, "=== VoiceAssistantProcess завершен ===");

        } catch (Exception e) {
            Log.e(TAG, "Ошибка в VoiceAssistantProcess: " + android.util.Log.getStackTraceString(e));
        }
    }

    private static void initSystemContext() {
        try {
            Log.d(TAG, "Инициализация системного контекста...");

            // Получаем ActivityThread и системный контекст
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");

            // Вызываем systemMain() для инициализации системного процесса
            Object activityThread = activityThreadClass.getMethod("systemMain").invoke(null);
            Log.d(TAG, "ActivityThread.systemMain() выполнен: " + activityThread);

            // Получаем системный контекст
            Object systemContext = activityThreadClass.getMethod("getSystemContext").invoke(activityThread);
            Log.d(TAG, "Системный контекст получен: " + systemContext);

            // Сохраняем контекст для дальнейшего использования
            systemContextRef = systemContext;

        } catch (Exception e) {
            Log.e(TAG, "Ошибка при инициализации системного контекста: " +
                    android.util.Log.getStackTraceString(e));
        }
    }

    private static Object systemContextRef = null;

    private static void testAutoService() {
        try {
            Log.d(TAG, "Тестирование доступа к автомобильному сервису...");

            if (systemContextRef == null) {
                Log.w(TAG, "Системный контекст не инициализирован");
                return;
            }

            // Получаем метод getSystemService через рефлексию
            Class<?> contextClass = systemContextRef.getClass();
            java.lang.reflect.Method getSystemServiceMethod =
                    contextClass.getMethod("getSystemService", String.class);

            // Список возможных автомобильных сервисов для тестирования
            String[] autoServices = {"auto", "car", "vehicle", "automotive"};

            for (String serviceName : autoServices) {
                try {
                    Object autoService = getSystemServiceMethod.invoke(systemContextRef, serviceName);

                    if (autoService != null) {
                        Log.d(TAG, "✅ Сервис '" + serviceName + "' найден: " + autoService.getClass().getName());

                        // Выводим доступные методы сервиса
                        listServiceMethods(autoService, serviceName);
                        return; // Нашли сервис, выходим

                    } else {
                        Log.d(TAG, "❌ Сервис '" + serviceName + "' не найден");
                    }

                } catch (Exception e) {
                    Log.d(TAG, "❌ Ошибка при получении сервиса '" + serviceName + "': " + e.getMessage());
                }
            }

            // Если автомобильные сервисы не найдены, попробуем получить список всех доступных
            listAllSystemServices();

        } catch (Exception e) {
            Log.e(TAG, "Ошибка при тестировании auto service: " +
                    android.util.Log.getStackTraceString(e));
        }
    }

    private static void listServiceMethods(Object service, String serviceName) {
        try {
            java.lang.reflect.Method[] methods = service.getClass().getMethods();
            Log.d(TAG, "Методы сервиса '" + serviceName + "':");

            int methodCount = 0;
            for (java.lang.reflect.Method method : methods) {
                String methodName = method.getName();

                // Показываем только интересные методы (set, get, control, etc.)
                if (methodName.contains("set") || methodName.contains("get") ||
                        methodName.contains("control") || methodName.contains("open") ||
                        methodName.contains("close") || methodName.contains("enable") ||
                        methodName.contains("disable")) {

                    Log.d(TAG, "  - " + methodName + "(" +
                            java.util.Arrays.toString(method.getParameterTypes()) + ")");
                    methodCount++;

                    // Ограничиваем вывод для читаемости
                    if (methodCount >= 10) {
                        Log.d(TAG, "  ... и еще " + (methods.length - methodCount) + " методов");
                        break;
                    }
                }
            }

            if (methodCount == 0) {
                Log.d(TAG, "  Полезные методы не найдены, всего методов: " + methods.length);
            }

        } catch (Exception e) {
            Log.e(TAG, "Ошибка при выводе методов сервиса: " + e.getMessage());
        }
    }

    private static void listAllSystemServices() {
        try {
            Log.d(TAG, "Получение списка всех системных сервисов...");

            // Получаем ServiceManager
            Class<?> serviceManagerClass = Class.forName("android.os.ServiceManager");
            java.lang.reflect.Method listServicesMethod = serviceManagerClass.getMethod("listServices");

            String[] services = (String[]) listServicesMethod.invoke(null);

            Log.d(TAG, "Найдено " + services.length + " системных сервисов:");

            // Ищем сервисы связанные с автомобилем
            for (String service : services) {
                if (service.toLowerCase().contains("auto") ||
                        service.toLowerCase().contains("car") ||
                        service.toLowerCase().contains("vehicle") ||
                        service.toLowerCase().contains("window") ||
                        service.toLowerCase().contains("door")) {

                    Log.d(TAG, "🚗 Потенциальный автомобильный сервис: " + service);
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Ошибка при получении списка сервисов: " + e.getMessage());
        }
    }
}